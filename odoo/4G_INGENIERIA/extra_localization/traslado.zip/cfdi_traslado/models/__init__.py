# -*- coding: utf-8 -*-


from . import autotransporte
from . import factura_traslado
from . import product
from . import res_partner
from . import stock_picking
